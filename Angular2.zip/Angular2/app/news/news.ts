export interface INews{
    newsId : string;
    newsTitle: string;
    newsSummary: string;
    newsContent: string;
    newsImageUrl: string;
    newsAuthor: string;
    postDate: string;
}