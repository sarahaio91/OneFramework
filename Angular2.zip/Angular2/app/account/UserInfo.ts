export interface IUserInfo{
    Role : string;
    Username: string;
    Password: string;
    Active: string;
   
}